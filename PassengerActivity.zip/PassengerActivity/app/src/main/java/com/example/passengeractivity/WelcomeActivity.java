package com.example.passengeractivity;

import static androidx.core.content.ContextCompat.startActivity;

